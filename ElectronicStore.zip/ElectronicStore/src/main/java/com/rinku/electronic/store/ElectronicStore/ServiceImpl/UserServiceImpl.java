package com.rinku.electronic.store.ElectronicStore.ServiceImpl;
import com.rinku.electronic.store.ElectronicStore.Dtos.UserDto;
import com.rinku.electronic.store.ElectronicStore.Entity.User;
import com.rinku.electronic.store.ElectronicStore.Repository.UserRepo;
import com.rinku.electronic.store.ElectronicStore.Service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private ModelMapper mapper;

    public UserDto createUser(UserDto userDto) {

        String UserID = UUID.randomUUID().toString();
        userDto.setUserId(UserID);
        //dto->entity
        User user = dtoToEntity(userDto);
        User saveUser = userRepo.save(user);
        //entity-> dto
        UserDto newDto = entityToDto(saveUser);
        return newDto;
    }

    public UserDto updateUser(UserDto userDto, String userId) {
        User user = this.userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not updated"));

        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setAbout(userDto.getAbout());
        user.setGender(userDto.getGender());
        user.setImageName(userDto.getImageName());
        User updatedUser = userRepo.save(user);
        UserDto updatedDto = entityToDto(updatedUser);
        return updatedDto;
    }

    //Delete User
    public void deleteUser(String userId) {
        User user = this.userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User Not found"));

        this.userRepo.delete(user);
    }

    //GetUserByID
    public UserDto getUserById(String userId) {
        User user = this.userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not Found"));
        return entityToDto(user);

    }

    //GetAll USer
    public List<UserDto> getAllUser() {
        List<User> users = userRepo.findAll();
        List<UserDto> dtoList = users.stream().map(user -> entityToDto(user)).collect(Collectors.toList());
        return dtoList;
    }

    public UserDto getUserByEmail(String email) {
        User user = userRepo.findByEmail(email).
                orElseThrow(() -> new RuntimeException("User not Found with given email id and password"));
        return entityToDto(user);
    }

    public List<UserDto> searchUser(String keyword) {
        List<User> users = userRepo.findByNameContaining(keyword);

        List<UserDto> dtoList = users.stream().map(user -> entityToDto(user)).collect(Collectors.toList());
        return dtoList;
    }

    private UserDto entityToDto(User savedUser) {
//        UserDto userDto=UserDto.builder()
//                .id(savedUser.getId())
//                .name(savedUser.getName())
//                .email(savedUser.getEmail())
//                .password(savedUser.getPassword())
//                .about(savedUser.getAbout())
//                .gender(savedUser.getGender())
//                .imageName(savedUser.getImageName()).build();
//                return userDto;


        return mapper.map(savedUser, UserDto.class);

    }

    private User dtoToEntity(UserDto userDto) {
        return mapper.map(userDto, User.class);


    }


}
